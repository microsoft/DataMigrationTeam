﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Orcale_CSV_XML
{
    class Program
    {
        static string repertoire = "Result_" + DateTime.Now.ToString("yyyyMMdd-hhmmss");
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("Please specify one CSV file");
                return;
            }
            var list = Extract(args[0]);
            System.IO.Directory.CreateDirectory(repertoire);
            GenerateServers(list);
            GenerateVariables(list);
            GenerateAssessmentReports(list);
            Console.WriteLine("Done");
            Console.ReadLine();
        }

        static List<Item> Extract(string file)
        {
            List<Item> items = new List<Item>();
            if (!File.Exists(file))
            {
                Console.WriteLine("Impossible de trouver le fichier " + file);
            }
            else
            {
                using (var fs = File.OpenRead(file))
                {
                    using (var reader = new StreamReader(fs))
                    {
                        while (!reader.EndOfStream)
                        {
                            var line = reader.ReadLine();
                            var values = line.Split(',');

                            if (values.Length >= 4)
                            {
                                Item it = new Item()
                                {
                                    Server = values[0].Trim(),
                                    Instance = values[1].Trim(),
                                    Schema = values[2].Trim(),
                                    Password = values[3].Trim()
                                };
                                items.Add(it);
                            }
                        }
                    }
                }
            }

            return items;
        }

        static void GenerateServers(List<Item> items)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("ServersConnectionFileTemplate.xml");
            var nodeServers = doc.SelectSingleNode("servers");
            var nodeOracle = doc.SelectSingleNode("servers/oracle");
            int i = 1;
            foreach (var item in items)
            {
                var copy = nodeOracle.CloneNode(true);
                copy.Attributes["name"].Value = "source_" + i;

                var nodeConn = copy.SelectSingleNode("connection-string-mode/custom-connection-string");
                var conn = nodeConn.Attributes["value"].Value;
                conn = conn.Replace("$OracleHostName1$", "$OracleHostName" + i + "$");
                conn = conn.Replace("PORT=1521", "PORT=1550");
                conn = conn.Replace("$OracleInstance1$", "$OracleInstance" + i + "$");
                conn = conn.Replace("$OracleUserName1$", "ssma_user");
                conn = conn.Replace("$OraclePassword1$", "ssma_user_pwd");
                nodeConn.Attributes["value"].Value = conn;

                nodeServers.AppendChild(copy);
                i++;
            }

            nodeServers.RemoveChild(nodeOracle);
            doc.Save(repertoire+@"\ServersConnectionFile.xml");
        }

        static void GenerateVariables(List<Item> items)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("VariableValueFileTemplate.xml");

            var nodeOracle = doc.SelectSingleNode("variables/variable-group[@name='OracleConnection']");

            List<Tuple<string, Func<Item, string>>> datasConnection = new List<Tuple<string, Func<Item, string>>>();
            datasConnection.Add(new Tuple<string, Func<Item, string>>("$OracleHostName", it => it.Server));
            datasConnection.Add(new Tuple<string, Func<Item, string>>("$OracleInstance", it => it.Instance));
            datasConnection.Add(new Tuple<string, Func<Item, string>>("$OraclPort", it => "Oracle_port"));
            datasConnection.Add(new Tuple<string, Func<Item, string>>("$OracleUserName", it => "ssma_user"));
            datasConnection.Add(new Tuple<string, Func<Item, string>>("$OraclePassword", it => "ssma_user_pwd"));
            datasConnection.Add(new Tuple<string, Func<Item, string>>("$OracleSchemaName", it => it.Schema));

            int i = 1;
            foreach (var item in items)
            {
                foreach (var data in datasConnection)
                {
                    var nodeHost = doc.CreateElement("variable");
                    nodeHost.Attributes.Append(doc.CreateAttribute("name")); nodeHost.Attributes["name"].Value = data.Item1 + i + "$";
                    nodeHost.Attributes.Append(doc.CreateAttribute("value")); nodeHost.Attributes["value"].Value = data.Item2(item);
                    nodeOracle.AppendChild(nodeHost);
                }                
                i++;
            }

            var nodeReport = doc.SelectSingleNode("variables/variable-group[@name='Report']");

            List<Tuple<string, Func<Item,int, string>>> datasReport = new List<Tuple<string, Func<Item,int, string>>>();

            datasReport.Add(new Tuple<string, Func<Item,int, string>>("$AssessmentReportFolderName", (it,inc) => it.Server+"_"+it.Instance+"_"+it.Schema));
            datasReport.Add(new Tuple<string, Func<Item, int, string>>("$SummaryReports", (it, inc) => @"$WorkingFolder$\$AssessmentReportFolderName"+inc+ "$"));
            datasReport.Add(new Tuple<string, Func<Item, int, string>>("$AssessmentReports", (it, inc) => @"$WorkingFolder$\$AssessmentReportFolderName" + inc + "$"));

            i = 1;
            foreach (var item in items)
            {
                foreach (var data in datasReport)
                {
                    var nodeHost = doc.CreateElement("variable");
                    nodeHost.Attributes.Append(doc.CreateAttribute("name")); nodeHost.Attributes["name"].Value = data.Item1 + i + "$";
                    nodeHost.Attributes.Append(doc.CreateAttribute("value")); nodeHost.Attributes["value"].Value = data.Item2(item,i);
                    nodeReport.AppendChild(nodeHost);
                }
                i++;
            }
            
            doc.Save(repertoire + @"\VariableValueFile.xml");
        }

        static void GenerateAssessmentReports(List<Item> items)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("AssessmentReportGenerationTemplate.xml");
            var nodeScript = doc.SelectSingleNode("ssma-script-file/script-commands");            
            int i = 1;
            foreach (var item in items)
            {
                var nodeConnectSource = nodeScript.SelectSingleNode("connect-source-database");
                nodeConnectSource.Attributes["server"].Value = "source_" + i;			

                var nodeGenerateAssessmentReport = nodeScript.SelectSingleNode("generate-assessment-report");
                nodeGenerateAssessmentReport.Attributes["object-name"].Value = "$OracleSchemaName" + i + "$";
                nodeGenerateAssessmentReport.Attributes["write-summary-report-to"].Value = "$SummaryReports" + i + "$";
                nodeGenerateAssessmentReport.Attributes["assessment-report-folder"].Value = "$AssessmentReports" + i + "$";

                var nodeForceLoad = nodeScript.SelectSingleNode("force-load");
                nodeForceLoad.Attributes["object-name"].Value = "$OracleSchemaName" + i + "$";

                doc.Save(repertoire + @"\AssessmentReportGeneration_source_" + i+".xml");
                i++;
            }            
        }
    }

    public class Item
    {
        public string Server { get; set; }
        public string Instance { get; set; }
        public string Schema { get; set; }

        public string Password { get; set; }

    }
}
