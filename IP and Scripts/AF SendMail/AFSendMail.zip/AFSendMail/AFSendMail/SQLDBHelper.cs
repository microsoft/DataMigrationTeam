﻿// Send Mail Azure Function

/*
 THE SOFTWARE CODE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
AND NONINFRINGEMENT. IN NO EVENT SHALL MICROSOFT OR ITS LICENSORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
SAMPLE CODE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace AFSendMail
{
    static internal class SQLDBHelper
    {
        static public void RetrieveSendMessages(string connString,  ILogger log)
        {
            // Connection String
            if (connString == null)
                throw new Exception("CONNECTION_STRING is undefined");

            // Data Set to return the messages for procesing
            var ds = new DataSet();

            using (var conn = new SqlConnection(connString))
            {
                // Opening connection
                conn.Open();

                ds.DataSetName = String.Format("{0}/{1}", conn.DataSource, conn.Database);

                // Beginnig Transaction
                using (var tran = conn.BeginTransaction(System.Data.IsolationLevel.RepeatableRead))
                {
                    string transavepoint = GetRandomString();
                    try
                    {
                        //  Select to retrieve the rows (skip rows locked by other instances or the application addding emails) batchsize if 1000
                        using (var command = new SqlCommand("SELECT TOP 1000 sender,tos_comma_separated,subject,plaintextcontent,htmlcontent,id FROM sendgridqueue WITH (updlock,readpast)", conn))
                        {
                            // Setup transaction
                            command.Transaction = tran;

                            // Execute command to a dataset
                            var da = new SqlDataAdapter(command);
                            da.Fill(ds);

                            // read from the dataset / Send the email within the transaction
                            foreach (DataRow r in ds.Tables[0].Rows)
                            {
                                // Save Transaction point
                                tran.Save(transavepoint = GetRandomString());

                                // Create new Email Message
                                string from = (string)r["sender"];
                                string to_list = (string)r["tos_comma_separated"];
                                string subject = (string)r["subject"];
                                string plainTextContent = (string)r["plaintextcontent"];
                                string htmlContent = (string)r["htmlcontent"];

                                // Send it
                                SendMailHelper.SendMailAsync(from, to_list, subject, plainTextContent, htmlContent, log).Wait();

                                // Delete processed rows
                                command.CommandText = String.Format("DELETE FROM sendgridqueue WHERE id = {0}", (int)r["id"]);
                                command.ExecuteNonQuery();
                            }
                            tran.Commit();
                        }
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            tran.Rollback(transavepoint);
                            tran.Commit();
                        }
                        finally
                        {
                            throw new Exception("SQLDBHelper exception", ex);
                        }
                    }
                }
            }
            
            log.LogInformation("Database {0} emails retrieved and sent: {1}", ds.DataSetName, ds.Tables[0].Rows.Count);
            
            return;
        }

        static string GetRandomString()
        {
            string str = String.Empty;
            for (int i = 0; i < 10; i++)
                str += (char)('a' + new Random().Next(0, 26));

            return str;
        }
    }
}
